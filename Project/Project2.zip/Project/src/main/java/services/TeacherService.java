package services;

import models.Teacher;

import java.util.List;

public interface TeacherService {

    List<Teacher> getAllStudents();
}

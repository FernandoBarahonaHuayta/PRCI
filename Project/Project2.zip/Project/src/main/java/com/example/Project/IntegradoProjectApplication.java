package com.example.Project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntegradoProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(IntegradoProjectApplication.class, args);
	}

}

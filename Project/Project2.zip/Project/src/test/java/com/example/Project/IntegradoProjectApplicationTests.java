package com.example.Project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntegradoProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
